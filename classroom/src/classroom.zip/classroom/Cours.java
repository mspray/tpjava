package classroom;

public class Cours {

}
